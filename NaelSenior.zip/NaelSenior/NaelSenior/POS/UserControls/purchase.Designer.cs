﻿namespace POS
{
    partial class purchase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_new = new System.Windows.Forms.Button();
            this.txt_Details = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel_add_new = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.main_cancel_btn = new System.Windows.Forms.Button();
            this.main_user_lbl = new System.Windows.Forms.Label();
            this.main_pass_lbl = new System.Windows.Forms.Label();
            this.main_ok_btn = new System.Windows.Forms.Button();
            this.main_user_txt = new System.Windows.Forms.TextBox();
            this.main_pass_txt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_q = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.combo_type = new System.Windows.Forms.ComboBox();
            this.combo_gen = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_model = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_close = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_sel = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_pur = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_quantity = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_num_product = new System.Windows.Forms.TextBox();
            this.comboBox_lvl3 = new System.Windows.Forms.ComboBox();
            this.comboBox_lvl2 = new System.Windows.Forms.ComboBox();
            this.comboBox_lvl1 = new System.Windows.Forms.ComboBox();
            this.list_purchase = new System.Windows.Forms.ListView();
            this.Model = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Generic = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Quantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbl_title = new System.Windows.Forms.Label();
            this.panel_add_new.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_new
            // 
            this.btn_new.Location = new System.Drawing.Point(187, 64);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(141, 35);
            this.btn_new.TabIndex = 4;
            this.btn_new.Text = "New Product";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // txt_Details
            // 
            this.txt_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Details.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.txt_Details.Location = new System.Drawing.Point(413, 41);
            this.txt_Details.Multiline = true;
            this.txt_Details.Name = "txt_Details";
            this.txt_Details.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_Details.Size = new System.Drawing.Size(221, 56);
            this.txt_Details.TabIndex = 31;
            this.txt_Details.Text = "No Information Available";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(689, 62);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(100, 35);
            this.btn_add.TabIndex = 33;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel_add_new
            // 
            this.panel_add_new.BackColor = System.Drawing.SystemColors.Control;
            this.panel_add_new.Controls.Add(this.panel2);
            this.panel_add_new.Controls.Add(this.label11);
            this.panel_add_new.Controls.Add(this.txt_q);
            this.panel_add_new.Controls.Add(this.label10);
            this.panel_add_new.Controls.Add(this.txt_price);
            this.panel_add_new.Controls.Add(this.combo_type);
            this.panel_add_new.Controls.Add(this.combo_gen);
            this.panel_add_new.Controls.Add(this.label9);
            this.panel_add_new.Controls.Add(this.txt_model);
            this.panel_add_new.Controls.Add(this.label7);
            this.panel_add_new.Controls.Add(this.label6);
            this.panel_add_new.Controls.Add(this.label5);
            this.panel_add_new.Controls.Add(this.panel_close);
            this.panel_add_new.Controls.Add(this.btn_add);
            this.panel_add_new.Controls.Add(this.txt_Details);
            this.panel_add_new.Controls.Add(this.label13);
            this.panel_add_new.Controls.Add(this.textBox1);
            this.panel_add_new.Controls.Add(this.label12);
            this.panel_add_new.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_add_new.Location = new System.Drawing.Point(0, 497);
            this.panel_add_new.Name = "panel_add_new";
            this.panel_add_new.Size = new System.Drawing.Size(800, 103);
            this.panel_add_new.TabIndex = 10;
            this.panel_add_new.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.splitContainer1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 103);
            this.panel2.TabIndex = 42;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.main_cancel_btn);
            this.splitContainer1.Panel2.Controls.Add(this.main_user_lbl);
            this.splitContainer1.Panel2.Controls.Add(this.main_pass_lbl);
            this.splitContainer1.Panel2.Controls.Add(this.main_ok_btn);
            this.splitContainer1.Panel2.Controls.Add(this.main_user_txt);
            this.splitContainer1.Panel2.Controls.Add(this.main_pass_txt);
            this.splitContainer1.Size = new System.Drawing.Size(800, 103);
            this.splitContainer1.SplitterDistance = 476;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 0;
            // 
            // main_cancel_btn
            // 
            this.main_cancel_btn.BackColor = System.Drawing.Color.Crimson;
            this.main_cancel_btn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.main_cancel_btn.FlatAppearance.BorderSize = 0;
            this.main_cancel_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.main_cancel_btn.Location = new System.Drawing.Point(149, 70);
            this.main_cancel_btn.Name = "main_cancel_btn";
            this.main_cancel_btn.Size = new System.Drawing.Size(75, 23);
            this.main_cancel_btn.TabIndex = 16;
            this.main_cancel_btn.Text = "Cancel";
            this.main_cancel_btn.UseVisualStyleBackColor = false;
            this.main_cancel_btn.Click += new System.EventHandler(this.panel_close_Click);
            // 
            // main_user_lbl
            // 
            this.main_user_lbl.AutoSize = true;
            this.main_user_lbl.BackColor = System.Drawing.Color.Transparent;
            this.main_user_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_user_lbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.main_user_lbl.Location = new System.Drawing.Point(28, 14);
            this.main_user_lbl.Name = "main_user_lbl";
            this.main_user_lbl.Size = new System.Drawing.Size(79, 17);
            this.main_user_lbl.TabIndex = 11;
            this.main_user_lbl.Text = "User Name";
            // 
            // main_pass_lbl
            // 
            this.main_pass_lbl.AutoSize = true;
            this.main_pass_lbl.BackColor = System.Drawing.Color.Transparent;
            this.main_pass_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_pass_lbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.main_pass_lbl.Location = new System.Drawing.Point(38, 38);
            this.main_pass_lbl.Name = "main_pass_lbl";
            this.main_pass_lbl.Size = new System.Drawing.Size(69, 17);
            this.main_pass_lbl.TabIndex = 12;
            this.main_pass_lbl.Text = "Password";
            // 
            // main_ok_btn
            // 
            this.main_ok_btn.BackColor = System.Drawing.Color.YellowGreen;
            this.main_ok_btn.FlatAppearance.BorderSize = 0;
            this.main_ok_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.main_ok_btn.Location = new System.Drawing.Point(238, 70);
            this.main_ok_btn.Name = "main_ok_btn";
            this.main_ok_btn.Size = new System.Drawing.Size(75, 23);
            this.main_ok_btn.TabIndex = 15;
            this.main_ok_btn.Text = "OK";
            this.main_ok_btn.UseVisualStyleBackColor = false;
            this.main_ok_btn.Click += new System.EventHandler(this.main_ok_btn_Click);
            // 
            // main_user_txt
            // 
            this.main_user_txt.Location = new System.Drawing.Point(113, 13);
            this.main_user_txt.Name = "main_user_txt";
            this.main_user_txt.Size = new System.Drawing.Size(200, 20);
            this.main_user_txt.TabIndex = 13;
            // 
            // main_pass_txt
            // 
            this.main_pass_txt.Location = new System.Drawing.Point(113, 37);
            this.main_pass_txt.Name = "main_pass_txt";
            this.main_pass_txt.PasswordChar = '*';
            this.main_pass_txt.Size = new System.Drawing.Size(200, 20);
            this.main_pass_txt.TabIndex = 14;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(640, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 20);
            this.label11.TabIndex = 41;
            this.label11.Text = "Quantity:";
            // 
            // txt_q
            // 
            this.txt_q.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_q.Location = new System.Drawing.Point(725, 7);
            this.txt_q.Name = "txt_q";
            this.txt_q.ShortcutsEnabled = false;
            this.txt_q.Size = new System.Drawing.Size(26, 26);
            this.txt_q.TabIndex = 32;
            this.txt_q.Text = "0";
            this.txt_q.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_discount_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(37, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "Price:";
            // 
            // txt_price
            // 
            this.txt_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_price.Location = new System.Drawing.Point(101, 74);
            this.txt_price.Name = "txt_price";
            this.txt_price.ShortcutsEnabled = false;
            this.txt_price.Size = new System.Drawing.Size(220, 26);
            this.txt_price.TabIndex = 30;
            // 
            // combo_type
            // 
            this.combo_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_type.FormattingEnabled = true;
            this.combo_type.Items.AddRange(new object[] {
            "Apple",
            "Bannana",
            "Jack Fruit",
            "Mango",
            "Orange"});
            this.combo_type.Location = new System.Drawing.Point(101, 40);
            this.combo_type.MaxDropDownItems = 12;
            this.combo_type.Name = "combo_type";
            this.combo_type.Size = new System.Drawing.Size(220, 28);
            this.combo_type.Sorted = true;
            this.combo_type.TabIndex = 29;
            this.combo_type.Enter += new System.EventHandler(this.combo_type_Enter);
            // 
            // combo_gen
            // 
            this.combo_gen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_gen.FormattingEnabled = true;
            this.combo_gen.Location = new System.Drawing.Point(413, 6);
            this.combo_gen.MaxDropDownItems = 12;
            this.combo_gen.Name = "combo_gen";
            this.combo_gen.Size = new System.Drawing.Size(221, 28);
            this.combo_gen.Sorted = true;
            this.combo_gen.TabIndex = 28;
            this.combo_gen.Enter += new System.EventHandler(this.combo_gen_Enter);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 20);
            this.label9.TabIndex = 19;
            this.label9.Text = "Model:";
            // 
            // txt_model
            // 
            this.txt_model.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_model.Location = new System.Drawing.Point(101, 7);
            this.txt_model.Name = "txt_model";
            this.txt_model.Size = new System.Drawing.Size(220, 26);
            this.txt_model.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(334, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Details:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(39, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Type:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(327, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Generic:";
            // 
            // panel_close
            // 
            this.panel_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel_close.FlatAppearance.BorderSize = 0;
            this.panel_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.panel_close.Image = global::POS.Properties.Resources.POS__6_;
            this.panel_close.Location = new System.Drawing.Point(757, 6);
            this.panel_close.Name = "panel_close";
            this.panel_close.Size = new System.Drawing.Size(32, 27);
            this.panel_close.TabIndex = 10;
            this.panel_close.UseVisualStyleBackColor = true;
            this.panel_close.Click += new System.EventHandler(this.panel_close_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(770, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 20);
            this.label13.TabIndex = 45;
            this.label13.Text = "%";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(711, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.ShortcutsEnabled = false;
            this.textBox1.Size = new System.Drawing.Size(57, 26);
            this.textBox1.TabIndex = 44;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_discount_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(640, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 20);
            this.label12.TabIndex = 43;
            this.label12.Text = "Sell at:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btn_sel);
            this.panel1.Controls.Add(this.btn_remove);
            this.panel1.Controls.Add(this.btn_pur);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txt_quantity);
            this.panel1.Controls.Add(this.btn_new);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txt_num_product);
            this.panel1.Controls.Add(this.comboBox_lvl3);
            this.panel1.Controls.Add(this.comboBox_lvl2);
            this.panel1.Controls.Add(this.comboBox_lvl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 392);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 105);
            this.panel1.TabIndex = 16;
            // 
            // btn_sel
            // 
            this.btn_sel.Location = new System.Drawing.Point(652, 64);
            this.btn_sel.Name = "btn_sel";
            this.btn_sel.Size = new System.Drawing.Size(100, 35);
            this.btn_sel.TabIndex = 40;
            this.btn_sel.Text = "Sell";
            this.btn_sel.UseVisualStyleBackColor = true;
            this.btn_sel.Click += new System.EventHandler(this.btn_sel_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(440, 64);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(100, 35);
            this.btn_remove.TabIndex = 39;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_pur
            // 
            this.btn_pur.Location = new System.Drawing.Point(546, 64);
            this.btn_pur.Name = "btn_pur";
            this.btn_pur.Size = new System.Drawing.Size(100, 35);
            this.btn_pur.TabIndex = 36;
            this.btn_pur.Text = "Purchase";
            this.btn_pur.UseVisualStyleBackColor = true;
            this.btn_pur.Click += new System.EventHandler(this.btn_pur_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(675, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 38;
            this.label1.Text = "Quantity:";
            // 
            // txt_quantity
            // 
            this.txt_quantity.Enabled = false;
            this.txt_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_quantity.Location = new System.Drawing.Point(679, 32);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.ShortcutsEnabled = false;
            this.txt_quantity.Size = new System.Drawing.Size(72, 26);
            this.txt_quantity.TabIndex = 31;
            this.txt_quantity.Text = "1";
            this.txt_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_discount_KeyPress);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(334, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 35);
            this.button1.TabIndex = 33;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(519, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 37;
            this.label4.Text = "Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(363, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 35;
            this.label3.Text = "Model:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 20);
            this.label2.TabIndex = 34;
            this.label2.Text = "Type:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(49, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 20);
            this.label8.TabIndex = 32;
            this.label8.Text = "Generic:";
            // 
            // txt_num_product
            // 
            this.txt_num_product.Enabled = false;
            this.txt_num_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num_product.Location = new System.Drawing.Point(523, 32);
            this.txt_num_product.Name = "txt_num_product";
            this.txt_num_product.ReadOnly = true;
            this.txt_num_product.Size = new System.Drawing.Size(150, 26);
            this.txt_num_product.TabIndex = 30;
            // 
            // comboBox_lvl3
            // 
            this.comboBox_lvl3.Enabled = false;
            this.comboBox_lvl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_lvl3.FormattingEnabled = true;
            this.comboBox_lvl3.Items.AddRange(new object[] {
            "Apple",
            "Bannana",
            "Jack Fruit",
            "Mango",
            "Orange"});
            this.comboBox_lvl3.Location = new System.Drawing.Point(367, 32);
            this.comboBox_lvl3.MaxDropDownItems = 12;
            this.comboBox_lvl3.Name = "comboBox_lvl3";
            this.comboBox_lvl3.Size = new System.Drawing.Size(150, 28);
            this.comboBox_lvl3.Sorted = true;
            this.comboBox_lvl3.TabIndex = 29;
            this.comboBox_lvl3.SelectedIndexChanged += new System.EventHandler(this.comboBox_lvl3_SelectedIndexChanged);
            // 
            // comboBox_lvl2
            // 
            this.comboBox_lvl2.Enabled = false;
            this.comboBox_lvl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_lvl2.FormattingEnabled = true;
            this.comboBox_lvl2.Items.AddRange(new object[] {
            "Apple",
            "Bannana",
            "Jack Fruit",
            "Mango",
            "Orange"});
            this.comboBox_lvl2.Location = new System.Drawing.Point(211, 32);
            this.comboBox_lvl2.MaxDropDownItems = 12;
            this.comboBox_lvl2.Name = "comboBox_lvl2";
            this.comboBox_lvl2.Size = new System.Drawing.Size(150, 28);
            this.comboBox_lvl2.Sorted = true;
            this.comboBox_lvl2.TabIndex = 28;
            this.comboBox_lvl2.SelectedIndexChanged += new System.EventHandler(this.comboBox_lvl2_SelectedIndexChanged);
            this.comboBox_lvl2.SelectionChangeCommitted += new System.EventHandler(this.comboBox_lvl2_SelectionChangeCommitted);
            // 
            // comboBox_lvl1
            // 
            this.comboBox_lvl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_lvl1.FormattingEnabled = true;
            this.comboBox_lvl1.Location = new System.Drawing.Point(53, 32);
            this.comboBox_lvl1.MaxDropDownItems = 12;
            this.comboBox_lvl1.Name = "comboBox_lvl1";
            this.comboBox_lvl1.Size = new System.Drawing.Size(150, 28);
            this.comboBox_lvl1.Sorted = true;
            this.comboBox_lvl1.TabIndex = 27;
            this.comboBox_lvl1.SelectedIndexChanged += new System.EventHandler(this.comboBox_lvl1_SelectedIndexChanged);
            this.comboBox_lvl1.SelectionChangeCommitted += new System.EventHandler(this.comboBox_lvl1_SelectionChangeCommitted);
            // 
            // list_purchase
            // 
            this.list_purchase.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_purchase.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.list_purchase.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Model,
            this.Generic,
            this.Type,
            this.Price,
            this.Quantity});
            this.list_purchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list_purchase.FullRowSelect = true;
            this.list_purchase.GridLines = true;
            this.list_purchase.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.list_purchase.Location = new System.Drawing.Point(0, 86);
            this.list_purchase.MultiSelect = false;
            this.list_purchase.Name = "list_purchase";
            this.list_purchase.Size = new System.Drawing.Size(800, 411);
            this.list_purchase.TabIndex = 23;
            this.list_purchase.UseCompatibleStateImageBehavior = false;
            this.list_purchase.View = System.Windows.Forms.View.Details;
            // 
            // Model
            // 
            this.Model.Text = "Model";
            this.Model.Width = 140;
            // 
            // Generic
            // 
            this.Generic.Text = "Generic";
            this.Generic.Width = 150;
            // 
            // Type
            // 
            this.Type.Text = "Type";
            this.Type.Width = 130;
            // 
            // Price
            // 
            this.Price.Text = "Price";
            this.Price.Width = 150;
            // 
            // Quantity
            // 
            this.Quantity.Text = "Quantity";
            this.Quantity.Width = 80;
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.BackColor = System.Drawing.Color.Transparent;
            this.lbl_title.Font = new System.Drawing.Font("Segoe UI Semilight", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title.ForeColor = System.Drawing.Color.DarkCyan;
            this.lbl_title.Location = new System.Drawing.Point(3, 18);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(478, 51);
            this.lbl_title.TabIndex = 65;
            this.lbl_title.Text = "Manual Sales and Purchases";
            // 
            // purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lbl_title);
            this.Controls.Add(this.list_purchase);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_add_new);
            this.Name = "purchase";
            this.Size = new System.Drawing.Size(800, 600);
            this.Load += new System.EventHandler(this.purchase_Load);
            this.panel_add_new.ResumeLayout(false);
            this.panel_add_new.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.TextBox txt_Details;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel panel_add_new;
        private System.Windows.Forms.Button panel_close;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_pur;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_quantity;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_num_product;
        private System.Windows.Forms.ComboBox comboBox_lvl3;
        private System.Windows.Forms.ComboBox comboBox_lvl2;
        private System.Windows.Forms.ComboBox comboBox_lvl1;
        private System.Windows.Forms.ListView list_purchase;
        private System.Windows.Forms.ColumnHeader Model;
        private System.Windows.Forms.ColumnHeader Generic;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Price;
        private System.Windows.Forms.ColumnHeader Quantity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_model;
        private System.Windows.Forms.ComboBox combo_gen;
        private System.Windows.Forms.ComboBox combo_type;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_q;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_sel;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button main_cancel_btn;
        private System.Windows.Forms.Label main_user_lbl;
        private System.Windows.Forms.Label main_pass_lbl;
        private System.Windows.Forms.Button main_ok_btn;
        private System.Windows.Forms.TextBox main_user_txt;
        private System.Windows.Forms.TextBox main_pass_txt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label12;
    }
}
