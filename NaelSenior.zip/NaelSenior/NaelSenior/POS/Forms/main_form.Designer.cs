﻿namespace POS
{
    partial class main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main_form));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salariesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.partiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expensesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDNewItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.converterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewLoansToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.registerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gatePassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.challanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.attendanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.main_splitContainer = new System.Windows.Forms.SplitContainer();
            this.Title = new System.Windows.Forms.Label();
            this.main_tabControl = new System.Windows.Forms.TabControl();
            this.tab_products = new System.Windows.Forms.TabPage();
            this.main_panel = new System.Windows.Forms.Panel();
            this.tab_accounting = new System.Windows.Forms.TabPage();
            this.accounting_tabControl = new System.Windows.Forms.TabControl();
            this.tab_banking = new System.Windows.Forms.TabPage();
            this.banking_panel = new System.Windows.Forms.Panel();
            this.tab_salary = new System.Windows.Forms.TabPage();
            this.employee_panel = new System.Windows.Forms.Panel();
            this.tab_parties = new System.Windows.Forms.TabPage();
            this.party_panel = new System.Windows.Forms.Panel();
            this.tab_expenses = new System.Windows.Forms.TabPage();
            this.expense_panel = new System.Windows.Forms.Panel();
            this.lbl_title = new System.Windows.Forms.Label();
            this.tab_ledger = new System.Windows.Forms.TabPage();
            this.info_splitContainer = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_sale_purchase = new System.Windows.Forms.Button();
            this.btn_info_partyle = new System.Windows.Forms.Button();
            this.buttonbankle = new System.Windows.Forms.Button();
            this.button_genle = new System.Windows.Forms.Button();
            this.info_panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.log_splitContainer = new System.Windows.Forms.SplitContainer();
            this.main_user_lbl = new System.Windows.Forms.Label();
            this.main_ok_btn = new System.Windows.Forms.Button();
            this.main_pass_lbl = new System.Windows.Forms.Label();
            this.main_pass_txt = new System.Windows.Forms.TextBox();
            this.main_user_txt = new System.Windows.Forms.TextBox();
            this.admin_pictureBox = new System.Windows.Forms.PictureBox();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.main_splitContainer)).BeginInit();
            this.main_splitContainer.Panel1.SuspendLayout();
            this.main_splitContainer.Panel2.SuspendLayout();
            this.main_splitContainer.SuspendLayout();
            this.main_tabControl.SuspendLayout();
            this.tab_products.SuspendLayout();
            this.tab_accounting.SuspendLayout();
            this.accounting_tabControl.SuspendLayout();
            this.tab_banking.SuspendLayout();
            this.tab_salary.SuspendLayout();
            this.tab_parties.SuspendLayout();
            this.tab_expenses.SuspendLayout();
            this.tab_ledger.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.info_splitContainer)).BeginInit();
            this.info_splitContainer.Panel1.SuspendLayout();
            this.info_splitContainer.Panel2.SuspendLayout();
            this.info_splitContainer.SuspendLayout();
            this.panel1.SuspendLayout();
            this.info_panel.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.log_splitContainer)).BeginInit();
            this.log_splitContainer.Panel1.SuspendLayout();
            this.log_splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip1.CanOverflow = false;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton2,
            this.toolStripButton9});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(984, 55);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::POS.Properties.Resources.POS__3_;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton1.Text = "Purchase and Sell";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::POS.Properties.Resources.POS__13_;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton3.Text = "View Stock";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::POS.Properties.Resources.POS__9_;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton4.Text = "Challan";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::POS.Properties.Resources.Public;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton5.Text = "Gate Pass";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::POS.Properties.Resources.History;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton6.Text = "Show Ledger";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::POS.Properties.Resources.POS__12_;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton7.Text = "Employee\'s Salary";
            this.toolStripButton7.Visible = false;
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::POS.Properties.Resources.POS__8_;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton8.Text = "Converter";
            this.toolStripButton8.Visible = false;
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::POS.Properties.Resources.POS__14_;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton2.Text = "register_new";
            this.toolStripButton2.Visible = false;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.ForeColor = System.Drawing.SystemColors.Control;
            this.toolStripButton9.Image = global::POS.Properties.Resources.POS__20_;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(105, 52);
            this.toolStripButton9.Text = "Statistics";
            this.toolStripButton9.Visible = false;
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.othersToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productsToolStripMenuItem,
            this.accountingToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // productsToolStripMenuItem
            // 
            this.productsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchaseToolStripMenuItem,
            this.sellToolStripMenuItem,
            this.stockToolStripMenuItem});
            this.productsToolStripMenuItem.Name = "productsToolStripMenuItem";
            this.productsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.productsToolStripMenuItem.Text = "Products..";
            // 
            // purchaseToolStripMenuItem
            // 
            this.purchaseToolStripMenuItem.Name = "purchaseToolStripMenuItem";
            this.purchaseToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.purchaseToolStripMenuItem.Text = "Purchase/Sales";
            this.purchaseToolStripMenuItem.Click += new System.EventHandler(this.purchaseToolStripMenuItem_Click);
            // 
            // sellToolStripMenuItem
            // 
            this.sellToolStripMenuItem.Name = "sellToolStripMenuItem";
            this.sellToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.sellToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.sellToolStripMenuItem.Text = "Manual Control";
            this.sellToolStripMenuItem.Click += new System.EventHandler(this.sellToolStripMenuItem_Click);
            // 
            // stockToolStripMenuItem
            // 
            this.stockToolStripMenuItem.Name = "stockToolStripMenuItem";
            this.stockToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.stockToolStripMenuItem.Text = "Stock";
            this.stockToolStripMenuItem.Click += new System.EventHandler(this.stockToolStripMenuItem_Click);
            // 
            // accountingToolStripMenuItem
            // 
            this.accountingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankingToolStripMenuItem,
            this.salariesToolStripMenuItem,
            this.partiesToolStripMenuItem,
            this.expensesToolStripMenuItem});
            this.accountingToolStripMenuItem.Name = "accountingToolStripMenuItem";
            this.accountingToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.accountingToolStripMenuItem.Text = "Accounting..";
            // 
            // bankingToolStripMenuItem
            // 
            this.bankingToolStripMenuItem.Name = "bankingToolStripMenuItem";
            this.bankingToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.bankingToolStripMenuItem.Text = "Banking";
            this.bankingToolStripMenuItem.Click += new System.EventHandler(this.bankingToolStripMenuItem_Click);
            // 
            // salariesToolStripMenuItem
            // 
            this.salariesToolStripMenuItem.Name = "salariesToolStripMenuItem";
            this.salariesToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.salariesToolStripMenuItem.Text = "Salaries";
            this.salariesToolStripMenuItem.Click += new System.EventHandler(this.salariesToolStripMenuItem_Click);
            // 
            // partiesToolStripMenuItem
            // 
            this.partiesToolStripMenuItem.Name = "partiesToolStripMenuItem";
            this.partiesToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.partiesToolStripMenuItem.Text = "Parties";
            this.partiesToolStripMenuItem.Click += new System.EventHandler(this.partiesToolStripMenuItem_Click);
            // 
            // expensesToolStripMenuItem
            // 
            this.expensesToolStripMenuItem.Name = "expensesToolStripMenuItem";
            this.expensesToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.expensesToolStripMenuItem.Text = "Expenses";
            this.expensesToolStripMenuItem.Click += new System.EventHandler(this.expensesToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDNewItemToolStripMenuItem,
            this.converterToolStripMenuItem,
            this.viewLoansToolStripMenuItem,
            this.toolStripSeparator4,
            this.registerToolStripMenuItem,
            this.addressToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // aDDNewItemToolStripMenuItem
            // 
            this.aDDNewItemToolStripMenuItem.Name = "aDDNewItemToolStripMenuItem";
            this.aDDNewItemToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.aDDNewItemToolStripMenuItem.Text = "ADD New Item...";
            this.aDDNewItemToolStripMenuItem.Click += new System.EventHandler(this.aDDNewItemToolStripMenuItem_Click);
            // 
            // converterToolStripMenuItem
            // 
            this.converterToolStripMenuItem.Name = "converterToolStripMenuItem";
            this.converterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.converterToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.converterToolStripMenuItem.Text = "Converter";
            this.converterToolStripMenuItem.Visible = false;
            this.converterToolStripMenuItem.Click += new System.EventHandler(this.barcodeSectionToolStripMenuItem_Click);
            // 
            // viewLoansToolStripMenuItem
            // 
            this.viewLoansToolStripMenuItem.Name = "viewLoansToolStripMenuItem";
            this.viewLoansToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.viewLoansToolStripMenuItem.Text = "View Ledger...";
            this.viewLoansToolStripMenuItem.Click += new System.EventHandler(this.viewLoansToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(197, 6);
            this.toolStripSeparator4.Visible = false;
            // 
            // registerToolStripMenuItem
            // 
            this.registerToolStripMenuItem.Name = "registerToolStripMenuItem";
            this.registerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.registerToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.registerToolStripMenuItem.Text = "Register...";
            this.registerToolStripMenuItem.Visible = false;
            this.registerToolStripMenuItem.Click += new System.EventHandler(this.registerToolStripMenuItem_Click);
            // 
            // addressToolStripMenuItem
            // 
            this.addressToolStripMenuItem.Name = "addressToolStripMenuItem";
            this.addressToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.addressToolStripMenuItem.Text = "Address";
            this.addressToolStripMenuItem.Click += new System.EventHandler(this.addressToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gatePassToolStripMenuItem,
            this.challanToolStripMenuItem,
            this.toolStripSeparator6,
            this.attendanceToolStripMenuItem});
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            // 
            // gatePassToolStripMenuItem
            // 
            this.gatePassToolStripMenuItem.Name = "gatePassToolStripMenuItem";
            this.gatePassToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.gatePassToolStripMenuItem.Text = "Gate Pass";
            this.gatePassToolStripMenuItem.Click += new System.EventHandler(this.gatePassToolStripMenuItem_Click);
            // 
            // challanToolStripMenuItem
            // 
            this.challanToolStripMenuItem.Name = "challanToolStripMenuItem";
            this.challanToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.challanToolStripMenuItem.Text = "Challan";
            this.challanToolStripMenuItem.Click += new System.EventHandler(this.challanToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(206, 6);
            // 
            // attendanceToolStripMenuItem
            // 
            this.attendanceToolStripMenuItem.Name = "attendanceToolStripMenuItem";
            this.attendanceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.A)));
            this.attendanceToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.attendanceToolStripMenuItem.Text = "Attendance";
            this.attendanceToolStripMenuItem.Click += new System.EventHandler(this.attendanceToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutUsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.aboutUsToolStripMenuItem.Text = "About Us";
            this.aboutUsToolStripMenuItem.Click += new System.EventHandler(this.aboutUsToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.helpToolStripMenuItem.Text = "Help...";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // main_splitContainer
            // 
            this.main_splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.main_splitContainer.IsSplitterFixed = true;
            this.main_splitContainer.Location = new System.Drawing.Point(0, 79);
            this.main_splitContainer.Name = "main_splitContainer";
            this.main_splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // main_splitContainer.Panel1
            // 
            this.main_splitContainer.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.main_splitContainer.Panel1.Controls.Add(this.Title);
            // 
            // main_splitContainer.Panel2
            // 
            this.main_splitContainer.Panel2.Controls.Add(this.main_tabControl);
            this.main_splitContainer.Size = new System.Drawing.Size(984, 682);
            this.main_splitContainer.SplitterDistance = 62;
            this.main_splitContainer.SplitterWidth = 1;
            this.main_splitContainer.TabIndex = 4;
            // 
            // Title
            // 
            this.Title.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Segoe UI Light", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.DimGray;
            this.Title.Location = new System.Drawing.Point(367, 10);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(165, 41);
            this.Title.TabIndex = 0;
            this.Title.Text = "Nael\'s Shop";
            // 
            // main_tabControl
            // 
            this.main_tabControl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.main_tabControl.Controls.Add(this.tab_products);
            this.main_tabControl.Controls.Add(this.tab_accounting);
            this.main_tabControl.Controls.Add(this.tab_ledger);
            this.main_tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_tabControl.ItemSize = new System.Drawing.Size(150, 50);
            this.main_tabControl.Location = new System.Drawing.Point(0, 0);
            this.main_tabControl.Multiline = true;
            this.main_tabControl.Name = "main_tabControl";
            this.main_tabControl.SelectedIndex = 0;
            this.main_tabControl.Size = new System.Drawing.Size(984, 619);
            this.main_tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.main_tabControl.TabIndex = 5;
            this.main_tabControl.SelectedIndexChanged += new System.EventHandler(this.main_tabControl_TabIndexChanged);
            // 
            // tab_products
            // 
            this.tab_products.BackColor = System.Drawing.SystemColors.Control;
            this.tab_products.Controls.Add(this.main_panel);
            this.tab_products.Location = new System.Drawing.Point(54, 4);
            this.tab_products.Name = "tab_products";
            this.tab_products.Padding = new System.Windows.Forms.Padding(3);
            this.tab_products.Size = new System.Drawing.Size(926, 611);
            this.tab_products.TabIndex = 0;
            this.tab_products.Text = "Products";
            // 
            // main_panel
            // 
            this.main_panel.BackColor = System.Drawing.SystemColors.Control;
            this.main_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_panel.Location = new System.Drawing.Point(3, 3);
            this.main_panel.Name = "main_panel";
            this.main_panel.Size = new System.Drawing.Size(920, 605);
            this.main_panel.TabIndex = 0;
            this.main_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.main_panel_Paint);
            // 
            // tab_accounting
            // 
            this.tab_accounting.BackColor = System.Drawing.SystemColors.Control;
            this.tab_accounting.Controls.Add(this.accounting_tabControl);
            this.tab_accounting.Controls.Add(this.lbl_title);
            this.tab_accounting.Location = new System.Drawing.Point(54, 4);
            this.tab_accounting.Name = "tab_accounting";
            this.tab_accounting.Padding = new System.Windows.Forms.Padding(3);
            this.tab_accounting.Size = new System.Drawing.Size(926, 611);
            this.tab_accounting.TabIndex = 1;
            this.tab_accounting.Text = "Accounting";
            // 
            // accounting_tabControl
            // 
            this.accounting_tabControl.Controls.Add(this.tab_banking);
            this.accounting_tabControl.Controls.Add(this.tab_salary);
            this.accounting_tabControl.Controls.Add(this.tab_parties);
            this.accounting_tabControl.Controls.Add(this.tab_expenses);
            this.accounting_tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.accounting_tabControl.ItemSize = new System.Drawing.Size(200, 30);
            this.accounting_tabControl.Location = new System.Drawing.Point(3, 3);
            this.accounting_tabControl.Multiline = true;
            this.accounting_tabControl.Name = "accounting_tabControl";
            this.accounting_tabControl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.accounting_tabControl.SelectedIndex = 0;
            this.accounting_tabControl.Size = new System.Drawing.Size(920, 605);
            this.accounting_tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.accounting_tabControl.TabIndex = 0;
            this.accounting_tabControl.Visible = false;
            // 
            // tab_banking
            // 
            this.tab_banking.BackColor = System.Drawing.SystemColors.Control;
            this.tab_banking.Controls.Add(this.banking_panel);
            this.tab_banking.Location = new System.Drawing.Point(4, 34);
            this.tab_banking.Name = "tab_banking";
            this.tab_banking.Padding = new System.Windows.Forms.Padding(3);
            this.tab_banking.Size = new System.Drawing.Size(912, 567);
            this.tab_banking.TabIndex = 0;
            this.tab_banking.Text = "Banking";
            // 
            // banking_panel
            // 
            this.banking_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.banking_panel.Location = new System.Drawing.Point(3, 3);
            this.banking_panel.Name = "banking_panel";
            this.banking_panel.Size = new System.Drawing.Size(906, 561);
            this.banking_panel.TabIndex = 0;
            // 
            // tab_salary
            // 
            this.tab_salary.BackColor = System.Drawing.SystemColors.Control;
            this.tab_salary.Controls.Add(this.employee_panel);
            this.tab_salary.Location = new System.Drawing.Point(4, 34);
            this.tab_salary.Name = "tab_salary";
            this.tab_salary.Padding = new System.Windows.Forms.Padding(3);
            this.tab_salary.Size = new System.Drawing.Size(912, 567);
            this.tab_salary.TabIndex = 1;
            this.tab_salary.Text = "Salary";
            // 
            // employee_panel
            // 
            this.employee_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.employee_panel.Location = new System.Drawing.Point(3, 3);
            this.employee_panel.Name = "employee_panel";
            this.employee_panel.Size = new System.Drawing.Size(906, 561);
            this.employee_panel.TabIndex = 0;
            // 
            // tab_parties
            // 
            this.tab_parties.BackColor = System.Drawing.SystemColors.Control;
            this.tab_parties.Controls.Add(this.party_panel);
            this.tab_parties.Location = new System.Drawing.Point(4, 34);
            this.tab_parties.Name = "tab_parties";
            this.tab_parties.Size = new System.Drawing.Size(912, 567);
            this.tab_parties.TabIndex = 2;
            this.tab_parties.Text = "Parties";
            // 
            // party_panel
            // 
            this.party_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.party_panel.Location = new System.Drawing.Point(0, 0);
            this.party_panel.Name = "party_panel";
            this.party_panel.Size = new System.Drawing.Size(912, 567);
            this.party_panel.TabIndex = 0;
            // 
            // tab_expenses
            // 
            this.tab_expenses.BackColor = System.Drawing.SystemColors.Control;
            this.tab_expenses.Controls.Add(this.expense_panel);
            this.tab_expenses.Location = new System.Drawing.Point(4, 34);
            this.tab_expenses.Name = "tab_expenses";
            this.tab_expenses.Padding = new System.Windows.Forms.Padding(3);
            this.tab_expenses.Size = new System.Drawing.Size(912, 567);
            this.tab_expenses.TabIndex = 3;
            this.tab_expenses.Text = "Expenses";
            // 
            // expense_panel
            // 
            this.expense_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.expense_panel.Location = new System.Drawing.Point(3, 3);
            this.expense_panel.Name = "expense_panel";
            this.expense_panel.Size = new System.Drawing.Size(906, 561);
            this.expense_panel.TabIndex = 0;
            // 
            // lbl_title
            // 
            this.lbl_title.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_title.AutoSize = true;
            this.lbl_title.BackColor = System.Drawing.Color.Transparent;
            this.lbl_title.Font = new System.Drawing.Font("Segoe UI Semilight", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title.ForeColor = System.Drawing.Color.DarkCyan;
            this.lbl_title.Location = new System.Drawing.Point(351, 193);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(182, 51);
            this.lbl_title.TabIndex = 65;
            this.lbl_title.Text = "Restricted";
            // 
            // tab_ledger
            // 
            this.tab_ledger.BackColor = System.Drawing.SystemColors.Control;
            this.tab_ledger.Controls.Add(this.info_splitContainer);
            this.tab_ledger.Location = new System.Drawing.Point(54, 4);
            this.tab_ledger.Name = "tab_ledger";
            this.tab_ledger.Size = new System.Drawing.Size(926, 611);
            this.tab_ledger.TabIndex = 2;
            this.tab_ledger.Text = "Info and Ledgers";
            // 
            // info_splitContainer
            // 
            this.info_splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.info_splitContainer.IsSplitterFixed = true;
            this.info_splitContainer.Location = new System.Drawing.Point(0, 0);
            this.info_splitContainer.Name = "info_splitContainer";
            this.info_splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // info_splitContainer.Panel1
            // 
            this.info_splitContainer.Panel1.Controls.Add(this.panel1);
            // 
            // info_splitContainer.Panel2
            // 
            this.info_splitContainer.Panel2.Controls.Add(this.info_panel);
            this.info_splitContainer.Size = new System.Drawing.Size(926, 611);
            this.info_splitContainer.SplitterDistance = 66;
            this.info_splitContainer.SplitterWidth = 1;
            this.info_splitContainer.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.Controls.Add(this.button_sale_purchase);
            this.panel1.Controls.Add(this.btn_info_partyle);
            this.panel1.Controls.Add(this.buttonbankle);
            this.panel1.Controls.Add(this.button_genle);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(920, 58);
            this.panel1.TabIndex = 3;
            // 
            // button_sale_purchase
            // 
            this.button_sale_purchase.Location = new System.Drawing.Point(634, 7);
            this.button_sale_purchase.Name = "button_sale_purchase";
            this.button_sale_purchase.Size = new System.Drawing.Size(164, 43);
            this.button_sale_purchase.TabIndex = 3;
            this.button_sale_purchase.Text = "Sales and Purchased History";
            this.button_sale_purchase.UseVisualStyleBackColor = true;
            this.button_sale_purchase.Click += new System.EventHandler(this.button_sale_purchase_Click);
            // 
            // btn_info_partyle
            // 
            this.btn_info_partyle.Location = new System.Drawing.Point(124, 7);
            this.btn_info_partyle.Name = "btn_info_partyle";
            this.btn_info_partyle.Size = new System.Drawing.Size(164, 43);
            this.btn_info_partyle.TabIndex = 0;
            this.btn_info_partyle.Text = "Show Party Ledger History";
            this.btn_info_partyle.UseVisualStyleBackColor = true;
            this.btn_info_partyle.Click += new System.EventHandler(this.btn_info_partyle_Click);
            // 
            // buttonbankle
            // 
            this.buttonbankle.Location = new System.Drawing.Point(464, 7);
            this.buttonbankle.Name = "buttonbankle";
            this.buttonbankle.Size = new System.Drawing.Size(164, 43);
            this.buttonbankle.TabIndex = 2;
            this.buttonbankle.Text = "Show Bank Transaction History";
            this.buttonbankle.UseVisualStyleBackColor = true;
            this.buttonbankle.Click += new System.EventHandler(this.buttonbankle_Click);
            // 
            // button_genle
            // 
            this.button_genle.Location = new System.Drawing.Point(294, 7);
            this.button_genle.Name = "button_genle";
            this.button_genle.Size = new System.Drawing.Size(164, 43);
            this.button_genle.TabIndex = 1;
            this.button_genle.Text = "Show General Ledger History";
            this.button_genle.UseVisualStyleBackColor = true;
            this.button_genle.Click += new System.EventHandler(this.button_genle_Click);
            // 
            // info_panel
            // 
            this.info_panel.Controls.Add(this.panel2);
            this.info_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.info_panel.Location = new System.Drawing.Point(0, 0);
            this.info_panel.Name = "info_panel";
            this.info_panel.Size = new System.Drawing.Size(926, 544);
            this.info_panel.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.log_splitContainer);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(926, 544);
            this.panel2.TabIndex = 10;
            // 
            // log_splitContainer
            // 
            this.log_splitContainer.Dock = System.Windows.Forms.DockStyle.Right;
            this.log_splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.log_splitContainer.IsSplitterFixed = true;
            this.log_splitContainer.Location = new System.Drawing.Point(574, 0);
            this.log_splitContainer.Name = "log_splitContainer";
            this.log_splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // log_splitContainer.Panel1
            // 
            this.log_splitContainer.Panel1.Controls.Add(this.main_user_lbl);
            this.log_splitContainer.Panel1.Controls.Add(this.main_ok_btn);
            this.log_splitContainer.Panel1.Controls.Add(this.main_pass_lbl);
            this.log_splitContainer.Panel1.Controls.Add(this.main_pass_txt);
            this.log_splitContainer.Panel1.Controls.Add(this.main_user_txt);
            this.log_splitContainer.Size = new System.Drawing.Size(352, 544);
            this.log_splitContainer.SplitterDistance = 220;
            this.log_splitContainer.SplitterWidth = 1;
            this.log_splitContainer.TabIndex = 11;
            // 
            // main_user_lbl
            // 
            this.main_user_lbl.AutoSize = true;
            this.main_user_lbl.BackColor = System.Drawing.Color.Transparent;
            this.main_user_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_user_lbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.main_user_lbl.Location = new System.Drawing.Point(28, 72);
            this.main_user_lbl.Name = "main_user_lbl";
            this.main_user_lbl.Size = new System.Drawing.Size(79, 17);
            this.main_user_lbl.TabIndex = 6;
            this.main_user_lbl.Text = "User Name";
            // 
            // main_ok_btn
            // 
            this.main_ok_btn.BackColor = System.Drawing.Color.YellowGreen;
            this.main_ok_btn.FlatAppearance.BorderSize = 0;
            this.main_ok_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.main_ok_btn.Location = new System.Drawing.Point(238, 126);
            this.main_ok_btn.Name = "main_ok_btn";
            this.main_ok_btn.Size = new System.Drawing.Size(75, 23);
            this.main_ok_btn.TabIndex = 10;
            this.main_ok_btn.Text = "OK";
            this.main_ok_btn.UseVisualStyleBackColor = false;
            this.main_ok_btn.Click += new System.EventHandler(this.main_ok_btn_Click);
            // 
            // main_pass_lbl
            // 
            this.main_pass_lbl.AutoSize = true;
            this.main_pass_lbl.BackColor = System.Drawing.Color.Transparent;
            this.main_pass_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_pass_lbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.main_pass_lbl.Location = new System.Drawing.Point(28, 97);
            this.main_pass_lbl.Name = "main_pass_lbl";
            this.main_pass_lbl.Size = new System.Drawing.Size(69, 17);
            this.main_pass_lbl.TabIndex = 7;
            this.main_pass_lbl.Text = "Password";
            // 
            // main_pass_txt
            // 
            this.main_pass_txt.Location = new System.Drawing.Point(113, 96);
            this.main_pass_txt.Name = "main_pass_txt";
            this.main_pass_txt.PasswordChar = '*';
            this.main_pass_txt.Size = new System.Drawing.Size(200, 20);
            this.main_pass_txt.TabIndex = 9;
            // 
            // main_user_txt
            // 
            this.main_user_txt.Location = new System.Drawing.Point(113, 71);
            this.main_user_txt.Name = "main_user_txt";
            this.main_user_txt.Size = new System.Drawing.Size(200, 20);
            this.main_user_txt.TabIndex = 8;
            // 
            // admin_pictureBox
            // 
            this.admin_pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.admin_pictureBox.BackColor = System.Drawing.Color.Transparent;
            this.admin_pictureBox.Image = global::POS.Properties.Resources.POS__1_;
            this.admin_pictureBox.Location = new System.Drawing.Point(928, 26);
            this.admin_pictureBox.Name = "admin_pictureBox";
            this.admin_pictureBox.Size = new System.Drawing.Size(53, 49);
            this.admin_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.admin_pictureBox.TabIndex = 0;
            this.admin_pictureBox.TabStop = false;
            this.admin_pictureBox.Tag = "";
            this.admin_pictureBox.Visible = false;
            // 
            // main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(984, 761);
            this.Controls.Add(this.main_splitContainer);
            this.Controls.Add(this.admin_pictureBox);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(850, 600);
            this.Name = "main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "nSales";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.main_form_FormClosed);
            this.Load += new System.EventHandler(this.main_form_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.main_splitContainer.Panel1.ResumeLayout(false);
            this.main_splitContainer.Panel1.PerformLayout();
            this.main_splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.main_splitContainer)).EndInit();
            this.main_splitContainer.ResumeLayout(false);
            this.main_tabControl.ResumeLayout(false);
            this.tab_products.ResumeLayout(false);
            this.tab_accounting.ResumeLayout(false);
            this.tab_accounting.PerformLayout();
            this.accounting_tabControl.ResumeLayout(false);
            this.tab_banking.ResumeLayout(false);
            this.tab_salary.ResumeLayout(false);
            this.tab_parties.ResumeLayout(false);
            this.tab_expenses.ResumeLayout(false);
            this.tab_ledger.ResumeLayout(false);
            this.info_splitContainer.Panel1.ResumeLayout(false);
            this.info_splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.info_splitContainer)).EndInit();
            this.info_splitContainer.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.info_panel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.log_splitContainer.Panel1.ResumeLayout(false);
            this.log_splitContainer.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.log_splitContainer)).EndInit();
            this.log_splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.admin_pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sellToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountingToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem converterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewLoansToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem registerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gatePassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem challanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        private System.Windows.Forms.SplitContainer main_splitContainer;
        private System.Windows.Forms.TabControl main_tabControl;
        private System.Windows.Forms.TabPage tab_products;
        private System.Windows.Forms.Panel main_panel;
        private System.Windows.Forms.TabPage tab_accounting;
        private System.Windows.Forms.TabControl accounting_tabControl;
        private System.Windows.Forms.TabPage tab_banking;
        private System.Windows.Forms.TabPage tab_salary;
        private System.Windows.Forms.Panel banking_panel;
        private System.Windows.Forms.Panel employee_panel;
        private System.Windows.Forms.TabPage tab_parties;
        private System.Windows.Forms.Panel party_panel;
        private System.Windows.Forms.TabPage tab_ledger;
        private System.Windows.Forms.SplitContainer info_splitContainer;
        private System.Windows.Forms.Panel info_panel;
        private System.Windows.Forms.Button btn_info_partyle;
        private System.Windows.Forms.PictureBox admin_pictureBox;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.Button button_genle;
        private System.Windows.Forms.TabPage tab_expenses;
        private System.Windows.Forms.Panel expense_panel;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonbankle;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.SplitContainer log_splitContainer;
        private System.Windows.Forms.Label main_user_lbl;
        private System.Windows.Forms.Button main_ok_btn;
        private System.Windows.Forms.Label main_pass_lbl;
        private System.Windows.Forms.TextBox main_pass_txt;
        private System.Windows.Forms.TextBox main_user_txt;
        private System.Windows.Forms.ToolStripMenuItem bankingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salariesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expensesToolStripMenuItem;
        private System.Windows.Forms.Button button_sale_purchase;
        private System.Windows.Forms.ToolStripMenuItem aDDNewItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addressToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem attendanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.Label Title;
    }
}